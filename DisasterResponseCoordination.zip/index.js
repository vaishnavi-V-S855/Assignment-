
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());

// Basic disaster route
app.get("/disasters", (req, res) => {
    res.json([{ id: 1, title: "NYC Flood", location_name: "Manhattan, NYC", tags: ["flood"], description: "Heavy flooding in Manhattan" }]);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
