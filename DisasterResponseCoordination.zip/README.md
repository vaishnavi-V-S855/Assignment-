
# Disaster Response Coordination Platform

## Setup

1. Install dependencies:
```
npm install
```

2. Start the backend server:
```
node index.js
```

3. Open `frontend/index.html` in your browser to see disaster reports.

## Notes
- Backend runs on port 3000
- Frontend fetches disaster data from the backend.
